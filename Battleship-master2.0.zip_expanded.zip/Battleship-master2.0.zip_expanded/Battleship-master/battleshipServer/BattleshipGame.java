package battleshipServer;

public class BattleshipGame {

	//This class will interface the Server Comms to the playGame class
	
	
	private int playerOne;
	private int playerTwo;
	
	public BattleshipGame() {
		
	}
	
}
