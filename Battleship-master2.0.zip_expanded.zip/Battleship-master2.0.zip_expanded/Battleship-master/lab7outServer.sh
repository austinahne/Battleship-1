java -cp .:ocsf.jar lab7out.ServerGUI
